# Support

For questions and help, jump on Gitter and ask away.  
[![Gitter](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/Makuna/Rtc?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge)

For documentation [See the Wiki](https://github.com/Makuna/Rtc/wiki)

For bugs, make sure there isn't an active issue and then create one.  Understand that issues are for bugs found in the library and not issues you are having with the library.  
